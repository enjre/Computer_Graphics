
    var canvas;
    var gl;

    var points = [];
    var colors = [];

    var cameraZoom = 45;
    var theta = Math.PI / 2;
    var dtheta = Math.PI / 128;
    var thetaLoc;

    
    var NumTimesToSubdivide = parseInt(prompt("Enter a number between 0-8","0"));

    if(NumTimesToSubdivide > 8) {
        NumTimesToSubdivide = 8;
    } else if (NumTimesToSubdivide < 0) {
        NumTimesToSubdivide = 0;
    }

    function init()
    {
        
        canvas = document.getElementById( "gl-canvas" );
        
        gl = WebGLUtils.setupWebGL( canvas );
        canvas.addEventListener('wheel', zoom);
        if ( !gl ) { alert( "WebGL isn't available" ); }

        
        
        
        var vertices = [
            vec3(  0.0000,  0.0000, -1.0000 ),
            vec3(  0.0000,  0.9428,  0.3333 ),
            vec3( -0.8165, -0.4714,  0.3333 ),
            vec3(  0.8165, -0.4714,  0.3333 )
        ];
        
        divideTetrahedron( vertices[0], vertices[1], vertices[2], vertices[3], NumTimesToSubdivide);

        
        
        gl.viewport( 0, 0, canvas.width, canvas.height );
        gl.clearColor( 0.4, 0.4, 0.4, 1.0 );
        
        
        gl.enable(gl.DEPTH_TEST);

      
        var program = initShaders( gl, "vertex-shader", "fragment-shader" );
        gl.useProgram(program);
        
    
        var cBuffer = gl.createBuffer();
        gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
        gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );
        
        var vColor = gl.getAttribLocation( program, "vColor" );
        gl.vertexAttribPointer( vColor, 3, gl.FLOAT, false, 0, 0 );
        gl.enableVertexAttribArray( vColor );

        var vBuffer = gl.createBuffer();
        gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
        gl.bufferData( gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW );

        var vPosition = gl.getAttribLocation( program, "vPosition" );
        gl.vertexAttribPointer( vPosition, 3, gl.FLOAT, false, 0, 0 );
        gl.enableVertexAttribArray(vPosition);

        thetaLoc = gl.getUniformLocation(program, "theta");

        

        render();
    };

    function triangle( a, b, c, color )
    {

        //Colors
        var FaceColors = [
            vec3(0.4, 0.0, 0.4), 
            vec3(0.2, 0.4, 0.0), 
            vec3(0.0, 0.4, 0.6), 
            vec3(0.8, 0.0, 0.4) 
        ];
        
        // face color
        colors.push( FaceColors[color] );
        points.push( a );
        colors.push( FaceColors[color] );
        points.push( b );
        colors.push( FaceColors[color] );
        points.push( c );
    }

    function tetrahedron( a, b, c, d )
    {
        
        
        triangle( a, c, b, 0 );
        triangle( a, c, d, 1 );
        triangle( a, b, d, 2 );
        triangle( b, c, d, 3 );
    }

    function divideTetrahedron( a, b, c, d, count )
    {
        // check for number of iterations
        
        if ( count === 0 ) {
            tetrahedron( a, b, c, d );
        }
        
        else {
            
            
            //Find bisector of each triangle edge
            var ab = mix( a, b, 0.5 );
            var ac = mix( a, c, 0.5 );
            var ad = mix( a, d, 0.5 );
            var bc = mix( b, c, 0.5 );
            var bd = mix( b, d, 0.5 );
            var cd = mix( c, d, 0.5 );

            --count;
            
            //Each division creates a new tetrahedron
            divideTetrahedron( a, ab, ac, ad, count );
            divideTetrahedron( ab, b, bc, bd, count );
            divideTetrahedron( ac, bc, c, cd, count );
            divideTetrahedron( ad, bd, cd, d, count );
        }
    }


    /**
		 * Handles the event of zooming in on our object by intercepting the wheel signal
		 * and setting a limit to how close/far the object can travel
		 *
		 * @param event
		 */
     function zoom(event) {
        // Stop the whole window from scrolling when on the canvas
        event.preventDefault();

        
        cameraZoom -= event.deltaY * 0.05;

        
        if (cameraZoom >= 150) {
            cameraZoom = 150; 
        }  else if (cameraZoom <= 1) {
            cameraZoom = 1; 
        }
    }

    window.onload = init;
    function render()
    {
        
        setTimeout(function () {
            requestAnimFrame(render);
            
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            theta += dtheta;
            gl.uniform1f(thetaLoc, theta);
            
            gl.clear(gl.COLOR_BUFFER_BIT);
            gl.drawArrays(gl.TRIANGLES, 0, points.length);

        }, 10);
        
    }
